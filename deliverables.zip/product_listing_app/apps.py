from django.apps import AppConfig


class ProductListingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'product_listing_app'
