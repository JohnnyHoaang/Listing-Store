from django.apps import AppConfig


class WebAdminAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'web_admin_app'
