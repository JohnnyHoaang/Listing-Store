"use strict"

document.addEventListener("DOMContentLoaded", setUp);
let global;
function setUp(){
    console.log("Hello World")
    global = {}
}





